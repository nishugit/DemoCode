﻿using Microsoft.Extensions.Logging;
using SampleMVCCoreApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleMVCCoreApplication.DAL
{
    public class EmployeeDAL : IEmployeeDAL
    {
        
        private DomainDbContext domainDbContext;
        
        public EmployeeDAL() { }

        public EmployeeDAL(DomainDbContext DbContext)
        {
            domainDbContext = DbContext;
           ;
        }
        public int SaveEmployee(Employee employee)
        {
            try
            {
                employee.DateCreated = DateTime.Now;

                domainDbContext.Employee.Add(employee);
                domainDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employee.Id;
        }
            public List<Employee> GetEmployees()
            {
            List<Employee> emp = new List<Employee>();
            try
            {

                emp = domainDbContext.Employee.Select(m => new Employee { FirstName = m.FirstName, LastName = m.LastName, Email = m.Email, Address = m.Address }).ToList();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return emp;
            }



            
        }
    }
