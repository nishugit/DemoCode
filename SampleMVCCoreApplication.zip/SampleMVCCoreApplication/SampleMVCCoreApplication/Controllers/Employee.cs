﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SampleMVCCoreApplication.BL;
using SampleMVCCoreApplication.DAL;
using SampleMVCCoreApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleMVCCoreApplication.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ILogger<EmployeeController> _logger;
        private IEmployeeBL employees;
        private DomainDbContext domainDbContext;
        public EmployeeController(IEmployeeBL employeeBL, DomainDbContext dbContext, ILogger<EmployeeController> logger)
        {
            employees = employeeBL;
            domainDbContext = dbContext;
            _logger = logger;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Members(Employee employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int employeeid = employees.SaveEmployee(employee);
                }
                else
                {
                    return Redirect("Registration");
                }
                EmployeesModel employeesModel = new EmployeesModel();
                employeesModel.Employees = employees.GetEmployees();
                return View(employeesModel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
        public ViewResult Registration()

        {
            {
                Employee employeeModel = new Employee();

                return View(employeeModel);

            }

        }
    }
}
