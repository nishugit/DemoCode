﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SampleMVCCoreApplication.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public DateTime DateCreated{ get; set; }
        [Required(ErrorMessage = "Name required")]
        public string FirstName { get; set; }
        public string LastName { get; set; }
    
        public string City { get; set; }

      
        public string Address { get; set; }
        
        [Required(ErrorMessage = "Telephone required")]
        [DisplayName("Telephone")]
        [Phone]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Email required")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsActive { get; set; }


    }
}
