﻿using SampleMVCCoreApplication.DAL;
using SampleMVCCoreApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleMVCCoreApplication.BL
{
    public class EmployeeBL : IEmployeeBL
    {
        private IEmployeeDAL employeeDAL;
        private DomainDbContext domainDbContext;
        public EmployeeBL(){}
        
        
        
        public EmployeeBL(IEmployeeDAL employee, DomainDbContext dbContext)
        {
            employeeDAL = employee;
            domainDbContext = dbContext;


        }
        public int SaveEmployee(Employee employee)
        {
            return employeeDAL.SaveEmployee(employee);


        }
        public List<Employee>GetEmployees()
        {
            return employeeDAL.GetEmployees();

        }
    }
}
