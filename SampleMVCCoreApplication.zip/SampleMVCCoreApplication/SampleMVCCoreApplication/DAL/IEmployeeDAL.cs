﻿using SampleMVCCoreApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleMVCCoreApplication.DAL
{
  public  interface IEmployeeDAL
    {
        int SaveEmployee(Employee employee);
        List<Employee> GetEmployees();
    }
}
