﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SampleMVCCoreApplication.Models;



namespace SampleMVCCoreApplication.DAL
{
    public class EmployeeConfiguration : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> builder)
        {
            builder.Property(p => p.Id).HasColumnName("Id");
            builder.Property(p => p.FirstName).HasColumnName("FirstName");
            builder.Property(p => p.LastName).HasColumnName("LastName");
            builder.Property(p => p.Email).HasColumnName("Email");
            builder.Property(p => p.Phone).HasMaxLength(320).HasColumnName("Phone");
            builder.Property(p => p.City).HasColumnName("City");
            builder.Property(p => p.IsActive).HasColumnName("IsActive");
            builder.Property(p => p.IsDeleted).HasColumnName("IsDeleted");


        }
    }
}
