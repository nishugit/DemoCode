﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SampleMVCCoreApplication.Models;
using System;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SampleMVCCoreApplication.DAL
{
    public class DomainDbContext : DbContext
    {
        //  private string conn = ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString();
        //private string conn { get;  set; }
        //public DomainDbContext() { }
        //public DomainDbContext(string Connection)
        //{
        //    Connection = conn;
        //}
        public DomainDbContext(DbContextOptions<DomainDbContext> options) : base(options) { }

        public virtual DbSet<Employee> Employee { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new EmployeeConfiguration());
        }
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(conn);
        //    base.OnConfiguring(optionsBuilder);

        //}

    }
}